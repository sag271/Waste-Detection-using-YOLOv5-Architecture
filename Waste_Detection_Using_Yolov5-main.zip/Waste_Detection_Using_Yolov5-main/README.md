# Waste-Detection-Using-Yolov5-

1. conda create -n waste 
2. conda activate waste